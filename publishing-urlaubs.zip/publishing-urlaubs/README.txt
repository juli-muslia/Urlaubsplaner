=== PublishingUrlaubs ===

Contact: https://julianmuslia.com
Tags: Calendar, planner, PublishingUrlaubs, publishing-group
Requires at least: 3.0.1
Tested up to: 6.0.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Publishing Group Urlaubs Plan is a Wordpress plugin developed for Publishing Group GmbH vacation planner. 
